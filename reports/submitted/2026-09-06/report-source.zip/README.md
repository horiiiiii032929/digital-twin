Build instructions: research/06_reports/final/README.md
Only the active concise report is packaged. No historical full appendix is required.
